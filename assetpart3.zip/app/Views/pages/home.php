<?= $this->extend('layouts/template');?>


<?= $this->section('content');?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>hello world</h1>
        </div>
    </div>
</div>
<?= $this->endSection();?>