<?= $this->extend('templates/index'); ?>

<?= $this->section('page-content'); ?>
<div class="pc-container">
  <div class="pc-content">
    <!-- [ breadcrumb ] start -->
    <!-- <div class="page-header">
        <div class="page-block">
          <div class="row align-items-center">
            <div class="col-md-12">
              <div class="page-header-title">
                <h5 class="m-b-10">Sample Page</h5>
              </div>
              <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="../dashboard/index.html">Home</a></li>
                <li class="breadcrumb-item"><a href="javascript: void(0)">Other</a></li>
                <li class="breadcrumb-item" aria-current="page">Sample Page</li>
              </ul>
            </div>
          </div>
        </div>
      </div> -->
    <!-- [ breadcrumb ] end -->

    <!-- [ Main Content ] start -->
    <div class="row">
      <!-- [ sample-page ] start -->
      <div class="col-sm-12">
        <div class="card">
          <div class="card-header">
            <h5>Pemasok</h5>
          </div>
          <div class="card tbl-card">
            <div class="card-body">
              <div class="table-responsive">
                <a href="pemasok/create" class="btn btn-outline-primary mb-3">Tambah Data Pemasok</a>
                <?php if (session()->getFlashdata('pesan')): ?>
                  <div class="alert alert-success">
                    <?= session()->getFlashdata('pesan');?>
                  </div>
                <?php endif; ?>
                <table id="myTable" class="table table-hover table-borderless">
                  <thead class="bg-light">
                    <tr class="text-nowrap">
                      <th scope="col">No</th>
                      <th scope="col">Kode Vendor</th>
                      <th scope="col">Nama Vendor</th>
                      <th scope="col">Alamat</th>
                      <th scope="col">Status</th>
                      <th scope="col">Created At</th>
                      <th scope="col">Updated At</th>
                      <th scope="col">Modified By</th>
                      <th scope="col">Handle</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($pemasok as $p) : ?>
                      <tr class="text-nowrap">
                        <th scope="row"><?= $i++; ?></th>
                        <td><?= $p['kode_vendor']; ?></td>
                        <td><?= $p['nama_vendor']; ?></td>
                        <td><?= $p['alamat']; ?></td>
                        <td>
                          <span class="badge <?= $p['status'] == 1 ? 'bg-success' : 'bg-danger'; ?> rounded-2">
                            <?= $p['status'] == 1 ? 'Aktif' : 'Tidak Aktif'; ?>
                          </span>
                        </td>
                        <td><?= $p['created_at']; ?></td>
                        <td><?= $p['updated_at']; ?></td>
                        <td><?= $p['modified_by']; ?></td>
                        <td>
                          <a href="" class="btn btn-warning">Edit</a>
                          <a href="" class="btn btn-danger">Delete</a>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- [ sample-page ] end -->
  </div>
  <!-- [ Main Content ] end -->
</div>
</div>
<script>
  const vendorModal = document.getElementById('exampleModalCenter');

  vendorModal.addEventListener('shown.bs.modal', function() {
    document.getElementById('kode_vendor').focus();
  });
</script>
<!-- [ Main Content ] end -->
<?= $this->endSection('page-content'); ?>